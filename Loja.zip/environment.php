<?php

define("ENVIRONMENT", "production");

?>
