<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Leonardo S">
    <meta name="keywords" content="developer, website, minecraft, templates, sites gratis">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>KaduPrays | Servidor de Minecraft</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Rajdhani" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/particles.js"></script>
    <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/app.js"></script>
    <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/particles.min.js"></script>
</head>
<body>

<section id="header">
    <div class="text-center pt-5 pb-5">
      <img src="<?php echo BASE_URL; ?>/arvorepreta.png" class="img-fluid">
    </div>
    <div id="navbar">
      <nav class="navbar navbar-expand-lg navbar-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarPri" aria-controls="navbarPri" aria-expanded="false" aria-label="Toggle navigation" style="margin: 15px 0">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarPri">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="/home"><i class="fas fa-gamepad"></i> KaduPrays <i class="fas fa-gamepad"></i></a>
              </li>
              <li class="nav-item">
              <a class="nav-link" href="/home"><i class="fa fa-fw fa-home"></i> Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/loja"><i class="fa fa-fw fa-gem"></i> Loja</a>
            </li>
          </ul>
        </div>
        <div class="justify-content-end" id="navbarPri">
          <ul class="navbar-nav">
            <li class="nav-item">
              <?php if(isset($_SESSION['log'])){
                echo '<a href="/login/sair" class="nav-link"><i class="fa fa-fw fa-user"></i> Bem vindo, <i>'.$_SESSION['usuario'].'</i></a>';
              }else{
                echo '<a href="/login" class="nav-link"><i class="fas fa-sign-in-alt"></i> Login</a>';
              } ?>
            </li>
            <li class="nav-item" id="carrinho">
              <a href="/loja/carrinho" class="nav-link"><i class="fa fa-fw fa-shopping-cart"></i> <?php if(isset($_SESSION['carrinho']) && isset($_SESSION['precoFixo'])){ echo count($_SESSION['carrinho']).' - R$ '.number_format($_SESSION['precoFixo'], 2, ',', '.'); }else{ echo '0 - R$ 0,00'; } ?></a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </section>
  <?php

  $this->loadViewInTemplate($name, $data);

  ?>
  <section id="footer">
    <div class="text-center">
      <div class="footer">
        <span> &copy; Todos os direitos reservados | KaduPrays | 2021 </span>
        <br>
      </div>
    </div>
  </section>

  <script src="<?php echo BASE_URL; ?>/assets/js/other.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/kadu.js"></script>

</body>
</html>
