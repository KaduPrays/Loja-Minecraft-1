<section id="center-dashboard">
  <div class="row">
    <div class="col-md-2">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
          <li class="list-group-item"><a href="/dashboard/pedidos"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</a></li>
          <li class="list-group-item"><a href="/dashboard/produtos"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</a></li>
          <li class="list-group-item"><a href="/dashboard/estatisticas"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</a></li>
          <li class="list-group-item"><a href="/dashboard/noticias"><i class="fa fa-fw fa-newspaper"></i> Noticias</a></li>
          <li class="list-group-item active"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-cog"></i> Configurações</a></li>
          <li class="list-group-item"><a href="/dashboardLogin/sair"><i class="fa fa-fw fa-times"></i> Encerrar Sessão</a></li>
        </ul>
      </div>
    </div>
    <div class="col-md-10">
      <div class="container">
        <div class="text-area mb-3">
          <h3>
            <i class="fa fa-fw fa-eye"></i> Configurações
          </h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item" aria-current="page"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-fw fa-cogs"></i> Configurações</li>
            </ol>
          </nav>
        </div>
        <div class="sidebar-module">
          <div class="card text-center">
            <h3 class="card-header">Criar tabelas no Banco de Dados</h3>
            <div class="card-body">
              <p>Para fazer as abas <b>Pedidos, Produtos e Estatisticas</b>, é necessario criar as tabelas no banco de dados. Você pode fazer isto facilmente clicando no botão abaixo!</p>
              <button class="btn btn-primary btn-lg btn-block" id="database">Criar tabelas</button>
            </div>
          </div>
        </div>
        <div class="sidebar-module">
          <form method="POST" id="cancelForm">
            <div class="card text-center">
              <div class="card-body">
                <div class="row pl-4">
                  <div class="col-md-6">
                    <div class="card">
                      <h3 class="card-header">Configurações de database</h3>
                      <div class="card-body">
                        <div class="row">
                          <div class="form-group col-md-6">
                            <label for="ip">IP</label>
                            <input type="text" id="ip" name="ip" class="form-control" value="<?php echo $dbhost; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="name">Nome</label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo $dbname; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="user">Usuario</label>
                            <input type="text" id="user" name="user" class="form-control" value="<?php echo $dbuser; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="pass">Senha</label>
                            <input type="password" id="pass" name="pass" class="form-control" value="<?php echo $dbpass; ?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="card">
                      <h3 class="card-header">Configurações do MercadoPago</h3>
                      <div class="card-body">
                        <div class="row">
                          <div class="form-group col-md-6">
                            <label for="client_id">Client_id</label>
                            <input type="text" id="client_id" name="client_id" class="form-control" value="<?php echo $client_id; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="client_secret">Client_secret</label>
                            <input type="text" id="client_secret" name="client_secret" class="form-control" value="<?php echo $client_secret; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="notificacao">URL de Notificação</label>
                            <input type="text" id="notificacao" name="notificacao" class="form-control" value="<?php echo $notificacao; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="retorno">URL de Retorno</label>
                            <input type="text" id="retorno" name="retorno" class="form-control" value="<?php echo $retorno; ?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="card">
                      <h3 class="card-header">Configurações Extras</h3>
                      <div class="card-body">
                        <div class="row">
                          <div class="form-group col-md-6">
                            <label for="discord">Discord</label>
                            <input type="text" id="discord" name="discord" class="form-control" value="<?php echo $discord; ?>">
                          </div>
                          <div class="form-group col-md-6">
                            <label for="twitter">Twitter</label>
                            <input type="text" id="twitter" name="twitter" class="form-control" value="<?php echo $twitter; ?>">
                          </div>
                          <div class="form-group col-md-12">
                            <label for="ipS">IP do servidor</label>
                            <input type="text" id="ipS" name="ipS" class="form-control" value="<?php echo $ipS; ?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12"><button class="btn btn-primary btn-lg btn-block" id="dados">Salvar dados</button></div>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="sidebar-module">
          <div class="card">
            <h3 class="card-header">Alterar senha do Painel</h3>
            <div class="card-body">
              <form action="/dashboard/configuracoes/alterarSenha" method="POST">
                <div class="form-group">
                  <label for="passNew">Nova senha</label>
                  <input type="password" id="passNew" name="passNew" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary btn-lg btn-block">Alterar</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
