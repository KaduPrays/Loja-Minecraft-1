<section id="center-dashboard">
  <div class="row">
    <div class="col-md-2">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item active"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
          <li class="list-group-item"><a href="/dashboard/pedidos"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</a></li>
          <li class="list-group-item"><a href="/dashboard/produtos"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</a></li>
          <li class="list-group-item"><a href="/dashboard/estatisticas"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-newspaper"></i> Noticias</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-cog"></i> Configurações</a></li>
          <li class="list-group-item"><a href="/dashboardLogin/sair"><i class="fa fa-fw fa-times"></i> Encerrar Sessão</a></li>
        </ul>
      </div>
    </div>
    <div class="col-md-10">
      <div class="container">
        <div class="text-area mb-5">
          <h3>
            <i class="fa fa-fw fa-eye"></i> Dashboard
          </h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item active" aria-current="page"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
            </ol>
          </nav>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="card mx-sm-1 p-3">
              <div class="card p-3 style-card" ><span class="fa fa-check fa-fw text-info" aria-hidden="true"></span></div>
              <div class="text-info text-center mt-3"><h4>Pedidos aprovados</h4></div>
              <div class="text-info text-center mt-2"><h1><?php echo $infos['pedidos']; ?></h1></div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card mx-sm-1 p-3">
              <div class="card p-3 style-card" ><span class="fa fa-shopping-bag fa-fw text-success" aria-hidden="true"></span></div>
              <div class="text-success text-center mt-3"><h4>Produtos criados</h4></div>
              <div class="text-success text-center mt-2"><h1><?php echo $infos['produtos']; ?></h1></div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card mx-sm-1 p-3">
              <div class="card p-3 style-card" ><span class="fa fa-money-bill-wave fa-fw text-warning" aria-hidden="true"></span></div>
              <div class="text-warning text-center mt-3"><h4>Dinheiro arrecadado</h4></div>
              <div class="text-warning text-center mt-2"><h1>R$<?php echo number_format($infos['dinheiro'], 2, '.', ','); ?></h1></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
