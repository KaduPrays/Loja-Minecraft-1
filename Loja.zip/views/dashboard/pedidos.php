<section id="center-dashboard">
  <div class="row">
    <div class="col-md-2">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
          <li class="list-group-item active"><a href="/dashboard/pedidos"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</a></li>
          <li class="list-group-item"><a href="/dashboard/produtos"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</a></li>
          <li class="list-group-item"><a href="/dashboard/estatisticas"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-newspaper"></i> Noticias</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-cog"></i> Configurações</a></li>
          <li class="list-group-item"><a href="/dashboardLogin/sair"><i class="fa fa-fw fa-times"></i> Encerrar Sessão</a></li>
        </ul>
      </div>
    </div>
    <div class="col-md-10">
      <div class="container">
        <div class="text-area mb-3">
          <h3>
            <i class="fa fa-fw fa-eye"></i> Pedidos Aprovados
          </h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item" aria-current="page"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</li>
            </ol>
          </nav>
        </div>
        <div class="card">
          <div class="card-body">
            <?php if($pedidos != 'Nada foi encontrado!'){ ?>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Usuario</th>
                  <th>ID Produto</th>
                  <th>Preço</th>
                  <th>Adquirido Em</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($pedidos as $view){ ?>
                <tr>
                  <td><?php echo $view['buy_user']; ?></td>
                  <td><?php echo $view['buy_items']; ?></td>
                  <td>R$<?php echo number_format($view['buy_preco'], 2, ',', '.'); ?></td>
                  <td><?php echo date('d/m/Y', strtotime($view['buy_data'])).' às '.$view['buy_hora']; ?></td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          <?php }else{ ?>
            <h1 class="text-center"><i class="fa fa-fw fa-frown-open fa-4x mb-4"></i><br>Nenhum pedido foi encontrado!</h1>
          <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
