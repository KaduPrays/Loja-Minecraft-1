<html>
    <!-- Sistema desenvolvido por KaduPrays -->
<head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>/assets/css/teste.css">
</head>
<body>
    <div id="particles-js"></div>
    <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/particles.js"></script>
    <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/app.js"></script>
    <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/particles.min.js"></script>
    <div class="loginbox">
        <form>
            <div>
            <h1><b>Área Administrativa</b><h1>
            <br>
            <img src="https://img.icons8.com/wired/98/000000/administrative-tools.png"/>
            </div>
            <div class="login-by-kadu">
            <i class="fas fa-sign-in-alt" style="color: white;font-size: 24px;"> Usuário</i>
            <input type="text" id="userA" name="userA" class="form-control">
            <div class="login-by-kadu">
            <i class="fas fa-key" style="color: white;font-size: 24px;"> Senha</i>
            <input type="password" id="passA" name="passA" class="form-control">
            <br>
            <a href=""><input type="submit" id="logarA" name="login" value="Login"></a>
            <br>
            <br>
            </div>
            </div>
        </form>
    </div>
</body>
</html>
