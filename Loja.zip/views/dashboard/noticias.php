<section id="center-dashboard">
  <div class="row">
    <div class="col-md-2">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
          <li class="list-group-item"><a href="/dashboard/pedidos"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</a></li>
          <li class="list-group-item"><a href="/dashboard/produtos"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</a></li>
          <li class="list-group-item"><a href="/dashboard/estatisticas"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</a></li>
          <li class="list-group-item active"><a href="/dashboard/noticias"><i class="fa fa-fw fa-newspaper"></i> Noticias</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-cog"></i> Configurações</a></li>
          <li class="list-group-item"><a href="/dashboardLogin/sair"><i class="fa fa-fw fa-times"></i> Encerrar Sessão</a></li>
        </ul>
      </div>
    </div>
    <div class="col-md-10">
      <div class="container">
        <div class="text-area mb-3">
          <h3>
            <i class="fa fa-fw fa-eye"></i> Noticias
          </h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item" aria-current="page"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-fw fa-newspaper"></i> Noticias</li>
            </ol>
          </nav>
        </div>
        <div class="card mb-4">
          <div class="card-body text-center">
            <?php if($_SERVER["REQUEST_URI"] == '/dashboard/noticias/view'){ ?>
            <h2><a href="/dashboard/noticias">Criar uma nova noticia</a></h2>
            <?php }else{ ?>
            <h2><a href="/dashboard/noticias/view">Visualizar noticias existentes</a></h2>
            <?php } ?>
          </div>
        </div>
        <div class="row">
        <?php if(isset($noticias)){ foreach($noticias as $view){ ?>
          <div class="col-md-4">
            <div class="sidebar-module">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-8 col-sm-12">
                      <h5><b><?php echo $view['noticia_titulo']; ?></b></h5>
                      <h6><?php echo $view['noticia_subtitulo']; ?></h6>
                    </div>
                    <div class="col-md-4 col-sm-12">
                      <small>Postado em <?php echo date('d/m/Y', strtotime($view['noticia_data'])).' às '.$view['noticia_hora']; ?></small>
                    </div>
                  </div>
                </div>
                <div class="card-footer text-center">
                  <a href="/dashboard/noticias/editar/<?php echo $view['noticia_id']; ?>" class="btn btn-primary btn-lg">Editar</a>
                  <a href="/dashboard/noticias/excluir/<?php echo $view['noticia_id']; ?>" class="btn btn-primary btn-lg">Excluir</a>
                </div>
              </div>
            </div>
          </div>
        <?php } }else if(isset($noticiasView) && is_array($noticiasView)){ ?>
          <div class="col-md-12">
            <div class="sidebar-module">
              <form method="POST" id="cancelForm" enctype="multipart/form-data">
                <div class="card">
                  <h3 class="card-header">Editando a noticia (<?php echo $noticiasView['noticia_titulo']; ?>)</h3>
                  <div class="card-body">
                    <div class="form-group">
                      <label for="id">ID da noticia</label>
                      <input type="text" id="id" name="id" class="form-control" value="<?php echo $noticiasView['noticia_id']; ?>" readonly="true">
                    </div>
                    <div class="form-group">
                      <label for="titulo">Titulo da noticia</label>
                      <input type="text" id="titulo" name="titulo" class="form-control" value="<?php echo $noticiasView['noticia_titulo']; ?>">
                    </div>
                    <div class="form-group">
                      <label for="subtitulo">Subtitulo da noticia</label>
                      <input type="text" id="subtitulo" name="subtitulo" class="form-control" value="<?php echo $noticiasView['noticia_subtitulo']; ?>">
                    </div>
                    <div class="form-group">
                      <label for="desc">Descrição da noticia</label>
                      <textarea name="desc" id="desc"><?php echo $noticiasView['noticia_desc']; ?></textarea>

                      <script src="<?php echo BASE_URL; ?>/assets/ckeditor/ckeditor.js"></script>
                      <script>CKEDITOR.replace('desc');</script>
                    </div>
                    <div class="text-center">
                      <small>Dê um duplo clique no botão para realizar as alterações!</small>
                    </div>
                    <button class="btn btn-block btn-lg btn-primary" id="editN">Editar noticia</button>
                  </div>
              </div>
              </form>
            </div>
          </div>
        <?php }else{ ?>
        <div class="col-md-12">
          <div class="sidebar-module">
            <form method="POST" id="cancelForm">
              <div class="card">
                <h3 class="card-header">Crie uma noticia</h3>
                <div class="card-body">
                  <div class="form-group">
                    <label for="titulo">Titulo da noticia</label>
                    <input type="text" id="titulo" name="titulo" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="subtitulo">Subitulo da noticia</label>
                    <input type="text" id="subtitulo" name="subtitulo" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="desc">Descrição da noticia</label>
                    <textarea name="desc" id="desc"></textarea>

                    <script src="<?php echo BASE_URL; ?>/assets/ckeditor/ckeditor.js"></script>
                    <script>CKEDITOR.replace('desc');</script>
                  </div>
                  <button class="btn btn-block btn-lg btn-primary" id="createN">Criar noticia</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
