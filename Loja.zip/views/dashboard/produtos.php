<section id="center-dashboard">
  <div class="row">
    <div class="col-md-2">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
          <li class="list-group-item"><a href="/dashboard/pedidos"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</a></li>
          <li class="list-group-item active"><a href="/dashboard/produtos"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</a></li>
          <li class="list-group-item"><a href="/dashboard/estatisticas"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-newspaper"></i> Noticias</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-cog"></i> Configurações</a></li>
          <li class="list-group-item"><a href="/dashboardLogin/sair"><i class="fa fa-fw fa-times"></i> Encerrar Sessão</a></li>
        </ul>
      </div>
    </div>
    <div class="col-md-10">
      <div class="container">
        <div class="text-area mb-3">
          <h3>
            <i class="fa fa-fw fa-eye"></i> Produtos
          </h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item" aria-current="page"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</li>
            </ol>
          </nav>
        </div>
        <div class="card mb-4">
          <div class="card-body text-center">
            <?php if($_SERVER["REQUEST_URI"] == '/dashboard/produtos/view'){ ?>
            <h2><a href="/dashboard/produtos">Criar um novo produto</a></h2>
            <?php }else{ ?>
            <h2><a href="/dashboard/produtos/view">Visualizar produtos existentes</a></h2>
            <?php } ?>
          </div>
        </div>
        <div class="row">
        <?php if(isset($produtos)){ foreach($produtos as $view){ ?>
            <div class="col-md-4">
              <div class="sidebar-module text-center">
                  <div class="card">
                    <img src="<?php echo BASE_URL ?>/assets/img/loja/vip.jpg" class="img-fluid">
                    <h3 class="card-header">
                      <b><?php echo $view['shop_prod']; ?></b><br>
                      <span class="price">R$<?php echo number_format($view['shop_preco'], 2, ',', '.'); ?></span><br>
                      <a href="/dashboard/produtos/editar/<?php echo $view['shop_id']; ?>" class="btn btn-primary btn-lg">Editar</a>
                      <a href="/dashboard/produtos/excluir/<?php echo $view['shop_id']; ?>" class="btn btn-primary btn-lg">Excluir</a>
                    </h3>
                  </div>
              </div>
            </div>
        <?php } }else if(isset($produtoView) && is_array($produtoView)){ ?>
            <div class="col-md-12">
                <div class="sidebar-module">
                    <form method="POST" id="cancelForm" enctype="multipart/form-data">
                        <div class="card">
                          <h3 class="card-header">Editando o produto (<?php echo $produtoView['shop_prod']; ?>)</h3>
                          <div class="card-body">
                              <div class="form-group">
                                <label for="id">ID do Produto</label>
                                <input type="text" id="id" name="id" class="form-control" value="<?php echo $produtoView['shop_id']; ?>" readonly="true">
                              </div>
                              <div class="form-group">
                                <label for="prod">Nome do produto</label>
                                <input type="text" id="prod" name="prod" class="form-control" value="<?php echo $produtoView['shop_prod']; ?>">
                              </div>
                              <div class="form-group">
                                <label for="cat">Categoria</label>
                                <input type="text" id="cat" name="cat" class="form-control" value="<?php echo $produtoView['shop_cat']; ?>">
                              </div>
                              <div class="form-group">
                                <label for="preco">Preço</label>
                                <input type="number" id="preco" name="preco" class="form-control" value="<?php echo $produtoView['shop_preco']; ?>">
                              </div>
                              <div class="form-group">
                                <label for="img">Link da imagem do produto</label>
                                <input type="text" id="img" name="img" class="form-control" value="<?php echo $produtoView['shop_img']; ?>">
                              </div>
                              <button class="btn btn-block btn-lg btn-primary" id="edit">Editar produto</button>
                          </div>
                      </div>
                    </form>
                </div>
            </div>
        <?php }else{ ?>
        <div class="col-md-12">
            <div class="sidebar-module">
                <form method="POST" id="cancelForm">
                    <div class="card">
                      <h3 class="card-header">Crie um produto</h3>
                      <div class="card-body">
                          <div class="form-group">
                            <label for="prod">Nome do produto</label>
                            <input type="text" id="prod" name="prod" class="form-control">
                          </div>
                          <div class="form-group">
                            <label for="cat">Categoria</label>
                            <input type="text" id="cat" name="cat" class="form-control">
                          </div>
                          <div class="form-group">
                            <label for="preco">Preço</label>
                            <input type="number" id="preco" name="preco" class="form-control">
                          </div>
                          <div class="form-group">
                            <label for="img">Link da Imagem do produto</label>
                            <input type="text" id="img" name="img" class="form-control">
                          </div>
                          <button class="btn btn-block btn-lg btn-primary" id="create">Criar produto</button>
                      </div>
                  </div>
                </form>
            </div>
        </div>
        <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
