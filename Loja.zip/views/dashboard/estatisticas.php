<section id="center-dashboard">
  <div class="row">
    <div class="col-md-2">
      <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
          <li class="list-group-item"><a href="/dashboard/pedidos"><i class="fa fa-fw fa-check"></i> Pedidos Aprovados</a></li>
          <li class="list-group-item"><a href="/dashboard/produtos"><i class="fa fa-fw fa-shopping-bag"></i> Produtos</a></li>
          <li class="list-group-item active"><a href="/dashboard/estatisticas"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</a></li>
          <li class="list-group-item"><a href="/dashboard/noticias"><i class="fa fa-fw fa-newspaper"></i> Noticias</a></li>
          <li class="list-group-item"><a href="/dashboard/configuracoes"><i class="fa fa-fw fa-cog"></i> Configurações</a></li>
          <li class="list-group-item"><a href="/dashboardLogin/sair"><i class="fa fa-fw fa-times"></i> Encerrar Sessão</a></li>
        </ul>
      </div>
    </div>
    <div class="col-md-10">
      <div class="container">
        <div class="text-area mb-3">
          <h3>
            <i class="fa fa-fw fa-eye"></i> Estatisticas
          </h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item" aria-current="page"><a href="/dashboard"><i class="fa fa-fw fa-rocket"></i> Dashboard</a></li>
              <li class="breadcrumb-item active" aria-current="page"><i class="fa fa-fw fa-chart-bar"></i> Estatisticas</li>
            </ol>
          </nav>
        </div>
        <div class="row" id="estatic">
          <div class="col-md-6 text-center">
            <div class="card">
              <div class="card-body">
                <h3><small>Faturamento da semana</small><br>R$<?php echo number_format($infos['Semana'], 2, ',', '.'); ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-6 text-center">
            <div class="card">
              <div class="card-body">
                <h3><small>Faturamento do dia</small><br>R$<?php echo number_format($infos['Dia'], 2, ',', '.'); ?></h3>
              </div>
            </div>
          </div>
          <?php if($produtos != 'Nenhum produto foi encontrado!'){ ?>
          <script type = "text/javascript" src = "https://www.gstatic.com/charts/loader.js">
          </script>
          <script type = "text/javascript">
             google.charts.load('current', {packages: ['corechart']});
          </script>
          <script language="JavaScript">
            function drawChart() {

              var data = new google.visualization.DataTable();
              data.addColumn('string', 'Produto');
              data.addColumn('number', 'Percentage');
              data.addRows([
                <?php for($i = 0; $i <= COUNT($produtos)-1; $i++){ if($i != COUNT($produtos)-1){ ?>
                [<?php echo $produtos[$i] ?>],
                <?php }else{ ?>
                [<?php echo $produtos[$i] ?>]
                <?php } } ?>
              ]);

              var options = {
                colors: ['#4a148c', '#6a1b9a', '#9c27b0'],
                is3D: true
              };

              var chart = new google.visualization.PieChart(document.getElementById('piechart'));
              chart.draw(data, options);
            }
            google.charts.setOnLoadCallback(drawChart);
          </script>
          <script type="text/javascript">
            google.load("visualization", "1", {packages:["corechart"]});
            google.setOnLoadCallback(drawChart);
            function drawChart() {
                //montando o array com os dados
                var data = google.visualization.arrayToDataTable([
                    ['Mês', 'Lucro'],
                    ['Jan',  <?php echo $infos['Jan']; ?>],
                    ['Fev',  <?php echo $infos['Fev']; ?>],
                    ['Mar',  <?php echo $infos['Mar']; ?>],
                    ['Abr',  <?php echo $infos['Abr']; ?>],
                    ['Mai',  <?php echo $infos['Mai']; ?>],
                    ['Jun',  <?php echo $infos['Jun']; ?>],
                    ['Jul',  <?php echo $infos['Jul']; ?>],
                    ['Ago',  <?php echo $infos['Ago']; ?>],
                    ['Set',  <?php echo $infos['Set']; ?>],
                    ['Out',  <?php echo $infos['Out']; ?>],
                    ['Nov',  <?php echo $infos['Nov']; ?>],
                    ['Dez',  <?php echo $infos['Dez']; ?>]
                ]);
                //opçoes para o gráfico barras
                var options = {
                  colors: ['#4a148c'],
                  vAxis: {title: 'Dinheiro recebido',  titleTextStyle: {color: 'black'}}
                };
                //instanciando e desenhando o gráfico barras
                var barras = new google.visualization.ColumnChart(document.getElementById('barras'));
                barras.draw(data, options);

            }
          </script>
          <div class="col-md-12">
            <div class="card">
              <h3 class="card-header">Arrecadação por mês</h3>
              <div class="card-body">
                <div id="barras"></div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="card">
              <h3 class="card-header">Produtos mais comprados</h3>
              <div class="card-body">
                <div id="piechart"></div>
              </div>
            </div>
          </div>
          <?php }else{ ?>
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <h1 class="text-center">
                  <i class="fa fa-fw fa-frown-open fa-4x mb-5"></i><br>
                  Nenhum produto foi encontrado!
                </h1>
              </div>
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
