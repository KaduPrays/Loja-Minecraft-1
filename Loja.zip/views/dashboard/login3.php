<head>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/teste.css" type="text/css">
</head>
<section id="center">
<div id="particles-js">
<script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/particles.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/app.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL; ?>/assets/js/particles.min.js"></script>
      <div class="card-body text-center">
        <h2><a style="color: black"><b>Bem vindo(a) DashBoard</b></a></h2>
        <br>
        <div style="width: 28rem; margin: 0 auto">
          <form method="POST" id="cancelForm" class="text-left">
            <div class="form-group">
              <img src="https://img.icons8.com/color/58/fa314a/badge.png"/><label for="userA"><a style="color: white;font-size: 25px;text-align: center;"><b>Usuario de acesso</b></a></label>
              <input type="text" id="userA" name="userA" class="form-control">
            </div>
            <div>
              <img src="https://img.icons8.com/color/45/000000/lock-2.png"/><label for="passA"><a style="color: white;font-size: 25px;text-align: center;"><b>Senha de acesso</b></a></label>
              <input type="password" id="passA" name="passA" class="form-control">
            </div>
            <br>
            <button class="btn btn-lg btn-primary btn-block" id="logarA">Acessar painel</button>  
            <br>
            <br>
            <br>
            <br>
            <br>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
