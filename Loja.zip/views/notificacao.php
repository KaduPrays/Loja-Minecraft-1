<section id="center">
  <div class="container">
    <div class="text-area">
      <h1>Informações sobre o pedido</h1>
      <div class="linha mb-5"></div>
    </div>
    <div class="text-center">
      <p>Pedido n° <b><?php $cod = explode('=', $items[2]); echo $cod[1]; ?></b></p>
      <p>Meio de Pagamento: <b><?php $metodo = explode('=', $items[3]); if($metodo[1] == 'ticket'){$tipo = 'boleto';}else if($metodo[1] == 'account_money'){$tipo = 'Saldo em Conta';}else if($metodo[1] == 'credit_card'){$tipo = 'Cartão de Crédito';}else{$tipo = 'Não encontrado';} echo $tipo; ?></b></p>
      <p><b>Caso seu pedido já tenha sido aprovado, basta configurar o IP e baixar seu plugin na aba "<?php echo $_SESSION['usuario']; ?>->Meus Plugins"</b></p>
      <p><b>Caso contrario, basta esperar a confirmação do pagamento e então você poderá baixar e usar seus plugins!</b></p>
      <a href="/usuario/profile" class="btn btn-primary btn-lg">Meu perfil</a>
    </div>
  </div>
</section>
