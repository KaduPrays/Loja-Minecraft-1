<div class="container text-center pt-5 pb-5"><br>
    <h1 class="text">
        <i class="fa fa-fw fa-exclamation-triangle fa-5x text-danger"></i><br>
        Opa...
    </h1>
    <h3 class="text">Site está em manutenção no momento</h3><br>
</div><br>
