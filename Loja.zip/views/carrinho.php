<section id="center">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <div class="card" id="carrinhoC">
          <h3 class="card-header text-left">
            Seus produtos
          </h3>
        </div>
        <?php
        foreach($items as $dados){
          echo $dados;
        }
        ?>
      </div>
      <div class="col-md-4">
        <?php if(isset($_SESSION['carrinho']) && isset($_SESSION['precoFixo'])) { ?>
        <div class="card" id="resumo">
          <h3 class="card-header text-left">
            Finalizando sua compra
          </h3>
        </div>
        <div class="card">
          <div class="card-body"><h5>Subtotal: <?php echo '<b>R$ '.number_format($_SESSION['precoFixo'], 2, ',', '.').'</b>';?></h5></div>
        </div>
        <div class="card">
          <div class="card-body"><h5>Total a pagar: <?php echo '<b>R$ '.number_format($_SESSION['precoFixo'], 2, ',', '.').'</b>';?></h5></div>
        </div>
        <div class="card">
          <div class="card-body">
            <a href="/loja/carrinho/finalizar" class="btn btn-primary btn-block btn-lg" id="finalizar">Finalizar compra</a>
          </div>
        </div>
      </div>
    <?php } ?>
    </div>
  </div>
</section>
