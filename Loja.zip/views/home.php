<section id="center">
  <div class="container">
    <div class="row">
      <div class="col-md-8" id="noticias">
        <?php if(!empty($noticias)){ foreach($noticias as $view){ ?>
        <div class="sidebar-module">
          <div class="card">
            <h3 class="card-header">
              <div class="row">
                <div class="col-md-2 text-center">
                  <img src="https://cravatar.eu/helmavatar/<?php echo $view['noticia_user']; ?>/96" class="img-fluid">
                </div>
                <div class="col-md-10">
                  <p>Postado por <b><?php echo $view['noticia_user']; ?></b></p>
                  <p>Em <?php echo date('d', strtotime($view['noticia_data'])).' de '.utf8_encode(strftime("%B", strtotime($view['noticia_data']))).' de '.date('Y', strtotime($view['noticia_data'])).' às '.date('H:i', strtotime($view['noticia_hora'])); ?></p>
                </div>
              </div>
            </h3>
            <div class="card-noticia">
              <h3><?php echo $view['noticia_titulo']; ?></h3>
              <h3><small><?php echo $view['noticia_subtitulo']; ?></small></h3>
            </div>
            <div class="card-body">
              <?php echo $view['noticia_desc']; ?>
            </div>
            <div class="card-footer text-left">
              <a href="/home/noticia/<?php echo $view['noticia_id']; ?>">Continuar lendo noticia...</a>
            </div>
          </div>
        </div>
      <?php } }else{ ?>
        <div class="sidebar-module">
          <div class="card">
            <div class="card-body text-center">
              <h2><i class="fa fa-fw fa-frown-open fa-4x mb-4"></i><br>Nenhuma noticia foi criada ainda!</h2>
            </div>
          </div>
        </div>
        <?php } ?>
      </div>
      <div class="col-md-4">
        <div class="sidebar-module">
          <div class="card">
            <h3 class="card-header">
              <i class="fa fa-fw fa-paper-plane"></i>
              Que tal jogar conosco?
            </h3>
            <div class="card-body">
              <input type="text" id="ipId" name="ipId" value="seuserver.kaduprays.com" style="border: none; background: transparent; text-align: center; font-size: 18px"><br>
              <button class="btn btn-primary btn-lg mb-2" id="ip">Copiar IP</button>
              <p><small>Basta clicar no botão para copiar nosso IP!</small></p>
            </div>
          </div>
        </div>
        <div class="sidebar-molude">
          <div class="card">
            <h3 class="card-header">
              <i class="fab fa-twitter"></i>
              Fique ligado em nosso Twitter
            </h3>
            <div class="card-body">
              <a class="twitter-timeline" data-width="100%" data-height="100%" href="https://twitter.com/<?php echo $twitter; ?>">Tweets by <?php echo $twitter; ?></a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>
          </div>
        </div>
        <div class="sidebar-molude mt-2">
          <div class="card">
            <iframe src="https://discord.com/widget?id=672052614694961182&theme=dark" width="350" height="500" allowtransparency="true" frameborder="0" sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
