<section id="center">
  <div class="container">
    <div class="sidebar-module">
      <div class="card">
        <div class="card-body">
          <h2><a href="/home">Voltar ao site</a></h2>
        </div>
      </div>
    </div>
    <div class="row" id="viewNoticia">
      <?php if($noticiaView != false){ foreach($noticiaView as $view){ ?>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body text-center">
            <img src="https://cravatar.eu/helmavatar/<?php echo $view['noticia_user']; ?>/296" class="img-fluid mb-4">
            <h3>Postado por <b><?php echo $view['noticia_user']; ?></b></h3>
            <h5>Em <?php echo date('d', strtotime($view['noticia_data'])).' de '.utf8_encode(strftime("%B", strtotime($view['noticia_data']))).' de '.date('Y', strtotime($view['noticia_data'])).' às '.date('H:i', strtotime($view['noticia_hora'])); ?></h5>
          </div>
        </div>
      </div>
      <div class="col-md-9">
        <div class="card">
          <div class="card-body text-justify">
            <?php echo $view['noticia_desc']; ?>
          </div>
        </div>
      </div>
    <?php } }else{ ?>
    <div class="col-md-12">
      <div class="card">
        <div class="card-body text-center">
          <h1><i class="fa fa-fw fa-frown-open fa-4x mb-4"></i><br>Nao conseguimos encontrar esta noticia</h1>
        </div>
      </div>
    </div>
    <?php } ?>
    </div>
  </div>
</section>
