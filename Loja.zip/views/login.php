<section id="center">
  <div class="container">
    <div class="card">
      <div class="card-header text-center">
        <h1>Faça login!</h1>
        <small>Note: recomendamos usar o mesmo nick que é usado em nossos sevidores! Evite problemas e use seu proprio nick para realizar compras.</small>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-4">
            <img src="https://minotar.net/body/MHF_Steve/100.png" class="img-fluid" id="userImg">
          </div>
          <div class="col-md-8 text-left">
            <form method="POST" id="cancelForm">
              <div class="form-group">
                <label for="userL">Usuario</label>
                <input type="text" id="userL" name="userL" class="form-control">
              </div>
              <button class="btn btn-primary btn-lg btn-block" id="login">Entrar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script>
$("#login").click(function(){

  var user = $("#userL").val();

  if(user.length > 0){
    $.post('/login/checkout', {user: user}, function(data){
      $("#login").html(data);
      setTimeout(function(){ window.location = '/home'; }, 3000);
    });
  }else{
    $("#userL").addClass("border border-danger");
    $("login").html("Campos devem ser preenchidos");
    setTimeout(function(){ $("#login").html("Entrar"); }, 3000);
  }

});
</script>
