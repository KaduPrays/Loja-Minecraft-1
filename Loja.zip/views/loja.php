<section id="center">
  <div class="container">
    <div class="row" id="cats">
      <div class="col-md-3">
        <div class="sidebar-module">
          <div class="card">
            <h3 class="card-header">
              <i class="fa fa-fw fa-list"></i> Categorias
            </h3>
            <ul class="list-group list-group-flush text-left">
              <li class="list-group-item <?php if($categoriaAtual == ''){ echo 'active'; } ?>"><i class="fa fa-fw fa-angle-right"></i> <a href="/loja">Todos</a></li>
            <?php if(!empty($cat)){ for($i = 0; $i < count($cat); $i++){ ?>
              <li class="list-group-item <?php if($categoriaAtual == $cat[$i]){ echo 'active'; } ?>"><i class="fa fa-fw fa-angle-right"></i> <a href="/loja/index/<?php echo $cat[$i]; ?>/pagina/1"><?php echo $cat[$i]; ?></a></li>
            <?php } }else{ ?>
              <h3 class="text-center pt-4 pb-4">Nenhuma categoria encontrada!</h3>
            <?php } ?>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-md-9">
        <div class="row" id="loja">
          <?php if(isset($produtos)){ foreach($produtos as $view){ ?>
          <div class="col-md-4">
            <div class="sidebar-module">
              <div class="card">
                <img src="<?php echo $view['shop_img']; ?>" class="img-fluid">
                <h3 class="card-header">
                  <b><?php echo $view['shop_prod']; ?></b><br>
                  <span class="price"><?php echo $view['shop_preco']; ?></span><br>
                  <a href="/loja/carrinho/add/<?php echo $view['shop_id']; ?>" class="btn btn-primary btn-lg">Comprar</a>
                </h3>
              </div>
            </div>
          </div>
        <?php } }else{ ?>
        <div class="col-md-12">
          <div class="card">
            <div class="card-body text-center">
              <h2><i class="fa fa-fw fa-frown-open fa-4x mb-4"></i><br>Nao conseguimos encontrar nenhum produto aqui</h2>
            </div>
          </div>
        </div>
        <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
