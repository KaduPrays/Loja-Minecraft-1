$("#ip").click(function(){
  $('#ipId').select();
  var copiar = document.execCommand('copy');
  if(copiar){
    $(this).html('COPIADO!');
    setTimeout(function(){ $('#ip').html('Copiar ip'); }, 3000);
  }else {
    alert('Erro ao copiar, seu navegador pode não ter suporte a essa função.');
  }
});

$("#cancelForm").submit(function(){
  return false;
});

$("#database").click(function(){

  var botao = $("#database");

  $.post('/dashboard/configuracoes/database', {create: 'true'}, function(data){
    botao.html(data);
  });

});

$("#logarA").click(function(){

  var user = $("#userA").val();
  var pass = $("#passA").val();

  $.post('/dashboardLogin/checkout', {user: user, pass: pass}, function(data){
    $("#logarA").html(data);
    if(data.match(/Logado com sucesso!/)){
      setTimeout(function(){ window.location = "/dashboard"; }, 2000);
    }
  });

});

$("#userL").keyup(function(){
  var user = $("#userL").val();

  if(user.length > 0){
    $("#userImg").attr("src", "https://minotar.net/body/"+user+"/100.png");
  }else{
    $("#userImg").attr("src", "https://minotar.net/body/MHF_Steve/100.png");
  }
});

$("#dados").click(function(){

  var user = $("#user").val();
  var pass = $("#pass").val();
  var name = $("#name").val();
  var ip = $("#ip").val();
  var client_id = $("#client_id").val();
  var client_secret = $("#client_secret").val();
  var notificacao = $("#notificacao").val();
  var retorno = $("#retorno").val();
  var discord = $("#discord").val();
  var twitter = $("#twitter").val();
  var ipS = $("#ipS").val();

  if(ip != ''){
    if(name != ''){
      if(user != ''){
        if(pass != ''){
          if(client_id != ''){
            if(client_secret != ''){
              if(notificacao != ''){
                if(retorno != ''){
                  if(discord != ''){
                    if(twitter != ''){
                      if(ipS != ''){
                        $.post('/dashboard/configuracoes/alterarDados', {user: user, pass: pass, name: name, ip: ip, client_id: client_id, client_secret: client_secret, notificacao: notificacao, retorno: retorno, discord: discord, twitter: twitter, ipS: ipS}, function(data){
                          $("#dados").html(data);
                          setTimeout(function(){ $("#dados").html("Salvar dados"); }, 4000);
                        });
                      }else{
                        $("#ipS").addClass("border border-danger");
                        $("#dados").html("IP do Servidor deve ser preenchido");
                        setTimeout(function(){ $("#ipS").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
                      }
                    }else{
                      $("#twitter").addClass("border border-danger");
                      $("#dados").html("Twitter deve ser preenchido");
                      setTimeout(function(){ $("#twitter").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
                    }
                  }else{
                    $("#discord").addClass("border border-danger");
                    $("#dados").html("Discord deve ser preenchido");
                    setTimeout(function(){ $("#discord").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
                  }
                }else{
                  $("#retorno").addClass("border border-danger");
                  $("#dados").html("Link de retorno deve ser preenchido");
                  setTimeout(function(){ $("#retorno").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
                }
              }else{
                $("#notificacao").addClass("border border-danger");
                $("#dados").html("Link de notificação deve ser preenchido");
                setTimeout(function(){ $("#notificacao").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
              }
            }else{
              $("#client_secret").addClass("border border-danger");
              $("#dados").html("CLIENT_SECRET deve ser preenchido");
              setTimeout(function(){ $("#client_secret").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
            }
          }else{
            $("#client_id").addClass("border border-danger");
            $("#dados").html("CLIENT_ID deve ser preenchido");
            setTimeout(function(){ $("#client_id").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
          }
        }else{
          $("#pass").addClass("border border-danger");
          $("#dados").html("Senha da tabela do Banco de Dados deve ser preenchido");
          setTimeout(function(){ $("#pass").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
        }
      }else{
        $("#user").addClass("border border-danger");
        $("#dados").html("Usuario do Banco de Dados deve ser preenchido");
        setTimeout(function(){ $("#user").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
      }
    }else{
      $("#name").addClass("border border-danger");
      $("#dados").html("Nome da tabela do Banco de Dados deve ser preenchido");
      setTimeout(function(){ $("#name").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
    }
  }else{
    $("#ip").addClass("border border-danger");
    $("#dados").html("IP do Banco de Dados deve ser preenchido");
    setTimeout(function(){ $("#ip").removeClass("border border-danger"); $("#dados").html("Salvar dados"); }, 4000);
  }

});

$("#edit").click(function(){
  var prod = $("#prod").val();
  var cat = $("#cat").val();
  var preco = $("#preco").val();
  var img = $("#img").val();
  var id = $("#id").val();

  $.post("/dashboard/produtos/editar/"+id+"/salvar", {prod: prod, cat: cat, preco: preco, id: id, img: img}, function(data){
    $("#edit").html(data);
    setTimeout(function(){ window.location="/dashboard/produtos/editar/"+id }, 2000);
  });
});
$("#create").click(function(){
  var prod = $("#prod").val();
  var cat = $("#cat").val();
  var preco = $("#preco").val();
  var img = $("#img").val();

  $.post("/dashboard/produtos/criar", {prod: prod, cat: cat, preco: preco, img: img}, function(data){
    $("#create").html(data);
    setTimeout(function(){ window.location="/dashboard/produtos" }, 2000);
  });
});

$("#editN").click(function(){
  var titulo = $("#titulo").val();
  var subtitulo = $("#subtitulo").val();
  var id = $("#id").val();
  var desc = $("#desc").val();

  $.post("/dashboard/noticias/editar/"+id+"/salvar", {titulo: titulo, subtitulo: subtitulo, desc: desc, id: id}, function(data){
    $("#editN").html(data);
    setTimeout(function(){ window.location="/dashboard/noticias/editar/"+id }, 2000);
  });
});
$("#createN").click(function(){
  var titulo = $("#titulo").val();
  var subtitulo = $("#subtitulo").val();
  var desc = $("#desc").val();

  $.post("/dashboard/noticias/criar", {titulo: titulo, subtitulo: subtitulo, desc: desc}, function(data){
    $("#createN").html(data);
    setTimeout(function(){ window.location="/dashboard/noticias" }, 2000);
  });
});
