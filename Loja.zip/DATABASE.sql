-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 13-Maio-2019 às 18:40
-- Versão do servidor: 5.7.26
-- versão do PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `danaymo_projeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `comprasAguardando`
--

CREATE TABLE `comprasAguardando` (
  `buy_id` int(11) NOT NULL,
  `buy_user` varchar(255) DEFAULT NULL,
  `buy_items` text,
  `buy_preco` varchar(255) DEFAULT '0',
  `buy_gateway` varchar(20) DEFAULT NULL,
  `buy_cod` text,
  `buy_data` date DEFAULT NULL,
  `buy_hora` time DEFAULT NULL,
  `buy_dataU` varchar(255) DEFAULT NULL,
  `buy_status` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comprasAprovadas`
--

CREATE TABLE `comprasAprovadas` (
  `buy_id` int(11) NOT NULL,
  `buy_user` varchar(255) DEFAULT NULL,
  `buy_items` text,
  `buy_preco` varchar(255) DEFAULT '0',
  `buy_gateway` varchar(1) DEFAULT NULL,
  `buy_cod` text,
  `buy_data` date DEFAULT NULL,
  `buy_hora` time DEFAULT NULL,
  `buy_dataU` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comprasCanceladas`
--

CREATE TABLE `comprasCanceladas` (
  `buy_id` int(11) NOT NULL,
  `buy_user` varchar(255) DEFAULT NULL,
  `buy_items` text,
  `buy_preco` varchar(255) DEFAULT NULL,
  `buy_gateway` varchar(1) DEFAULT NULL,
  `buy_cod` text,
  `buy_data` date DEFAULT NULL,
  `buy_hora` time DEFAULT NULL,
  `buy_dataU` varchar(255) DEFAULT NULL,
  `buy_status` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Estrutura da tabela `dashboard`
--

CREATE TABLE `dashboard` (
  `dash_id` int(11) NOT NULL,
  `dash_user` varchar(20) NOT NULL,
  `dash_pass` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `dashboard`
--

INSERT INTO `dashboard` (`dash_id`, `dash_user`, `dash_pass`) VALUES
(1, 'admin', '$2y$10$qS8espphh5Hihxy./RgG/O7TLY2jhF5uyHt.PGtV4qmVOsXZ8jNOW');

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticias`
--

CREATE TABLE `noticias` (
  `noticia_id` int(11) NOT NULL,
  `noticia_user` varchar(255) NOT NULL DEFAULT 'admin',
  `noticia_titulo` varchar(100) NOT NULL,
  `noticia_subtitulo` varchar(80) NOT NULL,
  `noticia_desc` text NOT NULL,
  `noticia_data` date NOT NULL,
  `noticia_hora` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `shopping`
--

CREATE TABLE `shopping` (
  `shop_id` int(11) NOT NULL,
  `shop_cat` varchar(120) NOT NULL,
  `shop_prod` varchar(180) NOT NULL,
  `shop_preco` varchar(10) NOT NULL,
  `shop_img` text,
  `shop_buys` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comprasAguardando`
--
ALTER TABLE `comprasAguardando`
  ADD PRIMARY KEY (`buy_id`);

--
-- Indexes for table `comprasAprovadas`
--
ALTER TABLE `comprasAprovadas`
  ADD PRIMARY KEY (`buy_id`);

--
-- Indexes for table `comprasCanceladas`
--
ALTER TABLE `comprasCanceladas`
  ADD PRIMARY KEY (`buy_id`);

--
-- Indexes for table `dashboard`
--
ALTER TABLE `dashboard`
  ADD PRIMARY KEY (`dash_id`);

--
-- Indexes for table `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`noticia_id`);

--
-- Indexes for table `shopping`
--
ALTER TABLE `shopping`
  ADD PRIMARY KEY (`shop_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comprasAguardando`
--
ALTER TABLE `comprasAguardando`
  MODIFY `buy_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comprasAprovadas`
--
ALTER TABLE `comprasAprovadas`
  MODIFY `buy_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comprasCanceladas`
--
ALTER TABLE `comprasCanceladas`
  MODIFY `buy_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dashboard`
--
ALTER TABLE `dashboard`
  MODIFY `dash_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `noticias`
--
ALTER TABLE `noticias`
  MODIFY `noticia_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shopping`
--
ALTER TABLE `shopping`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
