<?php

class controller {

    public function loadView($name, $data = array()){
        extract($data);
        include 'views/'.$name.'.php';
    }

    public function loadTemplate($name , $data = array(), $type = 1){
        extract($data);
        if($type != 1){
            include 'views/dashboard/template.php';
        }else{
            include 'views/template.php';
        }
    }

    public function loadViewInTemplate($name, $data = array()){
        extract($data);
        include 'views/'.$name.'.php';
    }

}

?>
