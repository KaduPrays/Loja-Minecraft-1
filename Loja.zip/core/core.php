<?php
setlocale( LC_ALL, 'pt_BR', 'pt_BR.iso-8859-1', 'pt_BR.utf-8', 'portuguese' );
class Core{

    private $currentController;
    private $currentAction;

    public function run(){

        $manu = 0;

        $url = explode("index.php", $_SERVER['REQUEST_URI']);
        $url = end($url);
        $url = str_replace(".php", "" ,$url);

        $params = array();
        if(!empty($url)){
            $url = explode('/', $url);
            array_shift($url);

            if($manu != 1){
                if(empty($url[0]) || $url[0] == 'manutencao'){
                    $currentController = 'homeController';
                    $currentAction = 'index';
                }else{
                    $currentController = $url[0].'Controller';

                    if(class_exists($currentController)){
                        array_shift($url);

                        if(isset($url[0])){
                            if(method_exists($currentController, $url[0])){
                                $currentAction = $url[0];
                            }else{
                                $currentAction = 'error404';
                            }
                            array_shift($url);
                        }else{
                            $currentAction = 'index';
                        }
                    }else{
                        $currentController = 'homeController';
                        $currentAction = 'error404';
                    }

                    if(count($url) > 0){
                        $params = $url;
                    }

                }
            }else{
                $currentController = 'manutencaoController';
                $currentAction = 'index';
            }

        }else{
            $currentController = 'homeController';
            $currentAction = 'index';
        }

        require_once 'core/controller.php';
        require_once 'core/bcrypt.php';

        $c = new $currentController();
        call_user_func_array(array($c, $currentAction), $params);

    }

}
