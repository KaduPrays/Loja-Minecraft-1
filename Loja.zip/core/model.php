<?php

class model {

    protected $db;
    protected $ftpUser;
    protected $ftpPass;
    protected $ftpHost;

    public function __construct(){

        global $config;

        try {

            $this->db = new PDO("mysql:host=".$config['dbhost'].";dbname=".$config['dbname']."; charset=utf8;", $config['dbuser'], $config['dbpass']);

        }catch(PDOException $e) {

            echo $e->getMessage();

        }

    }

}

?>
