<?php

require "environment.php";

define("BASE_URL", "https://localhost/");

global $config;
$config = array();

if(ENVIRONMENT == "development"){
  $config["dbhost"] = "localhost";
  $config["dbuser"] = "root";
  $config["dbname"] = "site";
  $config["dbpass"] = "Alpb100481!";
}else{
  $config["dbhost"] = "localhost";
  $config["dbuser"] = "root";
  $config["dbname"] = "site";
  $config["dbpass"] = "Alpb100481!";
  $config["client_id"] = "4916950658836862";
  $config["client_secret"] = "0JxjpBuc7q0dpyotNlSTb4WU3s6R5Jmf";
  $config["notificacao"] = "0";
  $config["retorno"] = "0";
  $config["discord"] = "https://discord.gg/msumG57Gqx";
  $config["twitter"] = "https://twitter.com/kaduprays";
  $config["ipS"] = "seuservidor.kaduprays.com";
}

?>