<?php

class notificacao extends model {

  public function get($id = null){

    global $config;

    $mp = new MP($config['client_id'], $config['client_secret']); /// suas credenciais do mercado pago

    $params = ["access_token" => $mp->get_access_token()];

    $payment_info = $mp->get("/collections/notifications/".$id, $params, false);

  	//tratando o status do pagamento para uma BR
  	switch($payment_info["response"]["collection"]["status"]){

  	case "approved"    : $status = "Pagamento Efetuado";	//O pagamento foi aprovado e creditado.
  	break;
      case "pending"	   : $status = "Aguardando Pagamento";    //O usuário não concluiu o processo de pagamento.
      break;
  	case "in_process"  : $status = "Aguardando Pagamento";	//O pagamento está sendo analisado.
      break;
  	case "rejected"	   : $status = "Cancelado"; //O pagamento foi recusado. O usuário pode tentar novamente.
      break;
  	case "refunded"    : $status = "Devolvido";//(estado terminal)	O pagamento foi devolvido ao usuário.
      break;
  	case "cancelled"   : $status = "Cancelado";//(estado terminal)	O pagamento foi cancelado por superar o tempo necessário para ser efetuado ou por alguma das partes.
      break;
  	case "in_mediation": $status = "Disputa"; //	Foi iniciada uma disputa para o pagamento.
  	break;

  	}


   ///-------tratando o formato da data-----------------------------
   //// data da compra
   $date = substr($payment_info["response"]["collection"]["date_created"],0,10); //formato original 2012-10-28T16:43:36.000-02:00
   $data_correta = explode("-",$date);
   $data_compra = $data_correta[2]."/". $data_correta[1] ."/".$data_correta[0];

   // data da atualização
   $date2 = substr($payment_info["response"]["collection"]["last_modified"],0,10); //formato original 2012-10-28T16:43:36.000-02:00
   $data_correta2 = explode("-",$date2);
   $data_update = $data_correta2[2]."/". $data_correta2[1] ."/".$data_correta2[0];
   //------------------------------------

    //codigo negociação
    $cod         = $payment_info["response"]["collection"]["id"];
    //referencia
    $ref         = $payment_info["response"]["collection"]["external_reference"];
    // data de compar e  data da ultima atualização do status tratada para BR
    $data_compra = $date;
    $data_update = $date2;
    //produto comprado
    $produto     = $payment_info["response"]["collection"]["reason"] ;
    //valor do item
    $valor       = $payment_info["response"]["collection"]["transaction_amount"];


    if($status == 'Aguardando Pagamento' || $status == 'Disputa' || $status == 'Pagamento Efetuado'){
      $stmt = "SELECT * FROM comprasAguardando WHERE buy_cod = :cod";
    }else{
      $stmt = "SELECT * FROM comprasAprovadas WHERE buy_cod = :cod";
    }

    $stmt = $this->db->prepare($stmt);
    $stmt->bindValue(":cod", $ref);
    $stmt->execute();

    if($stmt->rowCount() > 0){

     foreach($stmt as $set){
    	 $items = $set['buy_items'];
    	 $dataC = $set['buy_data'];
    	 $horaC = $set['buy_hora'];
    	 $preco = $set['buy_preco'];
       $email = $set['buy_email'];
       $usuario = $set['buy_user'];
     }

     $itemsE = explode(', ', $items);

     for($i = 0; $i < count($itemsE); $i++){
       $atualiza = "SELECT * FROM loja WHERE shop_id = $items[$i]";
       $atualiza = $this->db->query($atualiza);
       if($atualiza->rowCount() > 0){
         foreach($atualiza as $set){
           if($status == 'Pagamento Efetuado'){
             $views = $set['shopshop_views'] + 1;
           }else if($status == 'Cancelado' || $status == 'Devolvido' || $status == 'Disputa'){
             $views = $set['shop_views'] - 1;
           }
         }
         $atualiza = $this->db->query("UPDATE loja SET shop_views = $views WHERE shop_id = $items[$i]");
       }
     }

     if($status == 'Aguardando Pagamento' || $status == 'Disputa'){

    	 $stmt = "UPDATE INTO comprasAguardando SET buy_dataU = :data, buy_status = :status WHERE buy_cod = :cod";
    	 $stmt = $this->db->prepare($stmt);
    	 $stmt->bindValue(":data", $data_update);
    	 $stmt->bindValue(":status", $status);
    	 $stmt->bindValue(":cod", $ref);
    	 $stmt->execute();

    	 if($stmt){
    		 $remover = $this->db->query("DELETE FROM comprasAprovadas WHERE buy_cod = $ref");
    	 }

     }else if($status == 'Pagamento Efetuado'){

    	 $stmt = "INSERT INTO comprasAprovadas(buy_user, buy_email, buy_items, buy_preco, buy_gateway, buy_cod, buy_data, buy_hora, buy_dataU) VALUES(:user, :email, :items, :preco, :gateway, :cod, :data, :hora, :dataU)";
    	 $stmt = $this->db->prepare($stmt);
    	 $stmt->bindValue(":user", $usuario);
    	 $stmt->bindValue(":email", $email);
    	 $stmt->bindValue(":items", $items);
    	 $stmt->bindValue(":preco", $preco);
    	 $stmt->bindValue(":gateway", 'mercadopago');
    	 $stmt->bindValue(":cod", $ref);
       $stmt->bindValue(":data", date('Y-m-d', strtotime($dataC)));
    	 $stmt->bindValue(":hora", date('H:i:s', strtotime($horaC)));
    	 $stmt->bindValue(":dataU", date('Y-m-d', strtotime($data_update)));
    	 $stmt->execute();

    	 if($stmt){
    		 $remover = $this->db->query("DELETE FROM comprasAguardando WHERE buy_cod = $ref");
    	 }

     }else{

    	 $stmt = "INSERT INTO comprasCanceladas(buy_user, buy_email, buy_items, buy_preco, buy_gateway, buy_cod, buy_data, buy_hora, buy_dataU, buy_status) VALUES(:user, :email, :items, :preco, :gateway, :cod, :data, :hora, :dataU, :status)";
    	 $stmt = $this->db->prepare($stmt);
    	 $stmt->bindValue(":user", $usuario);
    	 $stmt->bindValue(":email", $email);
    	 $stmt->bindValue(":items", $items);
    	 $stmt->bindValue(":preco", $preco);
    	 $stmt->bindValue(":gateway", '1');
    	 $stmt->bindValue(":cod", $ref);
    	 $stmt->bindValue(":data", date('Y-m-d', strtotime($dataC)));
    	 $stmt->bindValue(":hora", date('H:i:s', strtotime($horaC)));
    	 $stmt->bindValue(":dataU", date('Y-m-d', strtotime($data_update)));
       $stmt->bindValue(":status", $status);
    	 $stmt->execute();

    	 if($stmt){
    		 $remover = $this->db->query("DELETE FROM comprasAguardando WHERE buy_cod = $ref");
    		 $remover2 = $this->db->query("DELETE FROM comprasAprovadas WHERE buy_cod = $ref");
    	 }

     }

   }

  }

}
