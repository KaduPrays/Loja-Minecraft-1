<?php

class dashboard extends model {

  public function deleteProduto($id){

    $sql = "SELECT * FROM shopping WHERE shop_id = '$id'";
    $sql = $this->db->query($sql);

    if($sql->rowCount() > 0){
      $sql = "DELETE FROM shopping WHERE shop_id = '$id'";
      $sql = $this->db->query($sql);
      if($sql){
        return 'Produto deletado com sucesso!';
      }else{
        return 'Erro ao deletar produto!';
      }
    }else{
      return 'Produto não foi encontrado!';
    }

  }

  public function deleteNoticia($id){

    $sql = "SELECT * FROM noticias WHERE noticia_id = '$id'";
    $sql = $this->db->query($sql);

    if($sql->rowCount() > 0){
      $sql = "DELETE FROM noticias WHERE noticia_id = '$id'";
      $sql = $this->db->query($sql);
      if($sql){
        return 'Noticia deletado com sucesso!';
      }else{
        return 'Erro ao deletar noticia!';
      }
    }else{
      return 'Noticia não foi encontrada!';
    }

  }

  public function alterarSenha($pass){

    $sql = "UPDATE dashboard SET dash_pass = :pass WHERE dash_user = 'admin'";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":pass", password_hash($pass, PASSWORD_DEFAULT));
    $sql->execute();

    if($sql){
      return 'Senha alterada com sucesso!';
    }else{
      return 'Erro ao alterar senha!';
    }

  }

  public function getMoney(){

    $array = array();

    $array['Jan'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-01-01' && buy_data <= '".date('Y')."-01-".date("t", mktime(0,0,0,'01','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Fev'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-02-01' && buy_data <= '".date('Y')."-02-".date("t", mktime(0,0,0,'02','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Mar'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-03-01' && buy_data <= '".date('Y')."-03-".date("t", mktime(0,0,0,'03','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Abr'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-04-01' && buy_data <= '".date('Y')."-04-".date("t", mktime(0,0,0,'04','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Mai'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-05-01' && buy_data <= '".date('Y')."-05-".date("t", mktime(0,0,0,'05','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Jun'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-06-01' && buy_data <= '".date('Y')."-06-".date("t", mktime(0,0,0,'06','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Jul'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-07-01' && buy_data <= '".date('Y')."-07-".date("t", mktime(0,0,0,'07','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Ago'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-08-01' && buy_data <= '".date('Y')."-08-".date("t", mktime(0,0,0,'08','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Set'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-09-01' && buy_data <= '".date('Y')."-09-".date("t", mktime(0,0,0,'09','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Out'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-10-01' && buy_data <= '".date('Y')."-10-".date("t", mktime(0,0,0,'10','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Nov'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-11-01' && buy_data <= '".date('Y')."-11-".date("t", mktime(0,0,0,'11','01',date('Y')))."'")->fetchColumn(), 2, '.', '');
    $array['Dez'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y')."-12-01' && buy_data <= '".date('Y')."-12-".date("t", mktime(0,0,0,'12','01',date('Y')))."'")->fetchColumn(), 2, '.', '');

    $array['Dia'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data = '".date('Y-m-d')."'")->fetchColumn(), 2, '.', ',');
    $array['Semana'] = number_format($this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin' AND buy_data >= '".date('Y-m-d')."' && buy_data <= '".date('Y-m-d', strtotime('+7 days'))."'")->fetchColumn(), 2, '.', '');

    return $array;

  }

  public function verificaBanco($table){

    $tableExists = $this->db->query("SHOW TABLES LIKE '$table'")->rowCount() > 0;

    return $tableExists;

  }

  public function verificaLinhas($table){

    $tableCounts = $this->db->query("SELECT COUNT(*) FROM $table")->fetchColumn();

    return $tableCounts;

  }

  public function getInfoD(){

    $array = array();

    $array['pedidos'] = $this->db->query("SELECT COUNT(*) FROM comprasAprovadas WHERE buy_user != 'admin'")->fetchColumn();
    $array['produtos'] = $this->db->query("SELECT COUNT(*) FROM shopping")->fetchColumn();
    $array['dinheiro'] = $this->db->query("SELECT SUM(buy_preco) FROM comprasAprovadas WHERE buy_user != 'admin'")->fetchColumn();

    return $array;

  }

  public function getProdutoInfo($id){

    $sql = "SELECT * FROM shopping WHERE shop_id = :id";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":id", $id);
    $sql->execute();

    if($sql->rowCount() > 0){
        $dados = $sql->fetch();
    }else{
        $dados = false;
    }

    return $dados;

  }

  public function getNoticiaInfo($id){

    $sql = "SELECT * FROM noticias WHERE noticia_id = :id";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":id", $id);
    $sql->execute();

    if($sql->rowCount() > 0){
        $dados = $sql->fetch();
    }else{
        $dados = false;
    }

    return $dados;

  }

  public function createTables(){

    $this->db->query("CREATE TABLE `shopping` (
      `shop_id` int(11) NOT NULL,
      `shop_cat` varchar(120) NOT NULL,
      `shop_prod` varchar(180) NOT NULL,
      `shop_preco` varchar(10) NOT NULL,
      `shop_buys` int(11) DEFAULT NULL
      ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
      ALTER TABLE `shopping`
        ADD PRIMARY KEY (`shop_id`);
      ALTER TABLE `shopping`
        MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT;
      COMMIT;
      CREATE TABLE `comprasAguardando` (
      `buy_id` int(11) NOT NULL AUTO_INCREMENT,
      `buy_user` varchar(255) DEFAULT NULL,
      `buy_email` text,
      `buy_items` text,
      `buy_preco` varchar(255) DEFAULT '0',
      `buy_gateway` varchar(1) DEFAULT NULL,
      `buy_cod` text,
      `buy_data` date DEFAULT NULL,
      `buy_hora` time DEFAULT NULL,
      `buy_dataU` varchar(255) DEFAULT NULL,
      `buy_status` varchar(255) DEFAULT NULL,
      PRIMARY KEY (`buy_id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
    CREATE TABLE `comprasAprovadas` (
    `buy_id` int(11) NOT NULL AUTO_INCREMENT,
    `buy_user` varchar(255) DEFAULT NULL,
    `buy_email` text,
    `buy_items` text,
    `buy_preco` varchar(255) DEFAULT '0',
    `buy_gateway` varchar(1) DEFAULT NULL,
    `buy_cod` text,
    `buy_data` date DEFAULT NULL,
    `buy_hora` time DEFAULT NULL,
    `buy_dataU` varchar(255) DEFAULT NULL,
    PRIMARY KEY (`buy_id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
    CREATE TABLE `comprasCanceladas` (
      `buy_id` int(11) NOT NULL AUTO_INCREMENT,
      `buy_user` varchar(255) DEFAULT NULL,
      `buy_email` text,
      `buy_items` text,
      `buy_preco` varchar(255) DEFAULT NULL,
      `buy_gateway` varchar(1) DEFAULT NULL,
      `buy_cod` text,
      `buy_data` date DEFAULT NULL,
      `buy_hora` time DEFAULT NULL,
      `buy_dataU` varchar(255) DEFAULT NULL,
      `buy_status` varchar(255) DEFAULT NULL,
      PRIMARY KEY (`buy_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;");

    echo 'Tabelas criadas com sucesso!';

  }

  public function getItems3(){

    $dados = array();

    $sql = "SELECT * FROM shopping WHERE shop_buys > '0' ORDER BY shop_buys DESC LIMIT 3";
    $sql = $this->db->query($sql);

    if($sql->rowCount() > 0){
      foreach($sql as $set){
        $dados[] = "'".$set['shop_prod']." (".$set['shop_cat'].")', ".$set['shop_buys'];
      }
    }else{
      $dados = 'Nenhum produto foi encontrado!';
    }

    return $dados;

  }

  public function editProduto($id, $prod, $cat, $preco, $img){

    $sql = "SELECT * FROM shopping WHERE shop_id = :id";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":id", $id);
    $sql->execute();

    if($sql->rowCount() > 0){
      $update = "UPDATE shopping SET shop_prod = :prod, shop_cat = :cat, shop_preco = :price, shop_img = :img WHERE shop_id = :id";
      $update = $this->db->prepare($update);
      $update->bindValue(":prod", $prod);
      $update->bindValue(":cat", $cat);
      $update->bindValue(":price", round($preco));
      $update->bindValue(":img", $img);
      $update->bindValue(":id", $id);
      $update->execute();
      if($update){
        return 'Produto alterado com sucesso!';
      }else{
        return 'Erro ao alterar produto, favor verifique!';
      }
    }else{
      return "Produto informado nao foi encontrado!";
    }

  }

  public function createProduto($prod, $cat, $preco, $img){

    $sql = "SELECT * FROM shopping WHERE shop_id = :prod";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":prod", $prod);
    $sql->execute();

    if($sql->rowCount() > 0){
      return 'Este produto ja existe, favor verifique!';
    }else{
      $update = "INSERT INTO shopping(shop_prod, shop_cat, shop_preco, shop_img) VALUES(:prod, :cat, :price, :img)";
      $update = $this->db->prepare($update);
      $update->bindValue(":prod", $prod);
      $update->bindValue(":cat", $cat);
      $update->bindValue(":price", round($preco));
      $update->bindValue(":img", $img);
      $update->execute();
      if($update){
        return 'Produto criado com sucesso!';
      }else{
        return 'Erro ao criar produto, favor verifique!';
      }
    }

  }

  public function editNoticia($id, $titulo, $subtitulo, $desc){

    $sql = "SELECT * FROM noticias WHERE noticia_id = :id";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":id", $id);
    $sql->execute();

    if($sql->rowCount() > 0){
      $update = "UPDATE noticias SET noticia_titulo = :titulo, noticia_subtitulo = :subtitulo, noticia_desc = :descricao WHERE noticia_id = :id";
      $update = $this->db->prepare($update);
      $update->bindValue(":titulo", $titulo);
      $update->bindValue(":subtitulo", $subtitulo);
      $update->bindValue(":descricao", $desc);
      $update->bindValue(":id", $id);
      $update->execute();
      if($update){
        return 'Noticia alterado com sucesso!';
      }else{
        return 'Erro ao alterar noticia, favor verifique!';
      }
    }else{
      return "Noticia informada nao foi encontrado!";
    }

  }

  public function createNoticia($titulo, $subtitulo, $desc){

    $sql = "SELECT * FROM noticias WHERE noticia_titulo = :titulo";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":titulo", $titulo);
    $sql->execute();

    if($sql->rowCount() > 0){
      return 'Ja existe uma noticia com esse titulo, favor verifique!';
    }else{
      $update = "INSERT INTO noticias(noticia_user, noticia_titulo, noticia_subtitulo, noticia_desc, noticia_data, noticia_hora) VALUES(:user, :titulo, :subtitulo, :descricao, :data, :hora)";
      $update = $this->db->prepare($update);
      $update->bindValue(":titulo", $titulo);
      $update->bindValue(":subtitulo", $subtitulo);
      $update->bindValue(":descricao", $desc);
      $update->bindValue(":data", date('Y-m-d'));
      $update->bindValue(":hora", date('H:i:s'));
      $update->bindValue(":user", $_SESSION['usuario']);
      $update->execute();
      if($update){
        return 'Noticia criada com sucesso!';
      }else{
        return 'Erro ao criar noticia, favor verifique!';
      }
    }

  }

}
