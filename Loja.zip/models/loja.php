<?php

class loja extends model {

  public function getCat(){

    $array = array();

    $sql = "SELECT * FROM shopping";
    $sql = $this->db->query($sql);

    if($sql->rowCount() > 0){
      foreach($sql as $set){

        if(in_array($set['shop_cat'], $array, true)){
          //nada a fazer
        }else{
          $array[] = $set['shop_cat'];
        }

      }
    }

    return $array;

  }

  public function addCarrinho($item){

      if(isset($_SESSION['log']) && $_SESSION['log'] == 1){

        if(is_numeric($item)){

          $sql = "SELECT * FROM shopping WHERE shop_id = :id";
          $sql = $this->db->prepare($sql);
          $sql->bindValue(":id", $item);
          $sql->execute();

          if($sql->rowCount() > 0){

            foreach($sql as $read_produto_view);
            if(isset($_SESSION['carrinho'][$item])){
              $_SESSION['carrinho'][$item] += 1;
            }else {
              $_SESSION['carrinho'][$item] = 1;
            }

            echo '<script>alert("Produto adicionado com sucesso!"); window.location = "/loja/carrinho";</script>';

          }else{
          echo '<script>alert("Produto não encontrado!"); window.location = "/loja";</script>';
          }

        }else{
          echo '<script>alert("Erro: Falta de parametros!"); window.location = "/loja/carrinho";</script>';
        }

      }else{
        echo '<script>alert("Você precisa estar logado para fazer isso!"); window.location = "/login";</script>';
      }

  }

  public function getCarrinho(){

    $dados = array();
    $i = 0;
    if(!empty($_SESSION['carrinho'])) {
      foreach($_SESSION['carrinho'] as $id_produto_carrinho => $quantidade_produto_carrinho) {

        $id_produto_carrinho = str_replace('%20', ' ', $id_produto_carrinho);

        $read_produto_carrinho = $this->db->query("SELECT * FROM shopping WHERE shop_id = '".$id_produto_carrinho."'");
        if($read_produto_carrinho->rowCount() > 0) {
          $i++;
          foreach($read_produto_carrinho as $read_produto_carrinho_view);
          $valor_total_produto_carrinho = $quantidade_produto_carrinho * $read_produto_carrinho_view['shop_preco'];
          $_SESSION['total'] += $valor_total_produto_carrinho;
          if(empty($_SESSION['precoFixo'])){
              $_SESSION['precoFixo'] = $valor_total_produto_carrinho;
          }else{
              if($i == 1){
                  $_SESSION['precoFixo'] = 0;
              }
              $_SESSION['precoFixo'] += $valor_total_produto_carrinho;
          }
          $dados[] = '
          <div class="card" id="prodInfo">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6 text-left">
                  <b>'.rawurldecode($read_produto_carrinho_view['shop_prod']).'</b>
                  <br>
                  Servidor: <b>'.rawurldecode($read_produto_carrinho_view['shop_cat']).'</b>
                </div>
                <div class="col-md-2">
                  '.$quantidade_produto_carrinho.'
                </div>
                <div class="col-md-2">
                  R$'.number_format($valor_total_produto_carrinho, 2, ',', '.').'
                </div>
                <div class="col-md-2">
                  <a href="/loja/carrinho/remover/'.$id_produto_carrinho.'"><i class="fa fa-trash"></i></a>
                </div>
              </div>
            </div>
          </div>';
        }
      }
    }else {
      $dados[] = '<h1 class="text-center pt-5 pb-5"><i class="fa fa-question fa-fw fa-4x mb-4"></i><br>Nada foi encontrado em seu carrinho</h1>';
    }

    return $dados;

  }

  public function createPedido(){

    if(isset($_SESSION['log'])){
      $_SESSION['carrinho'] = str_replace('%20', ' ', $_SESSION['carrinho']);

      $items = '';
      $itemsFinal = '';
      for($i = 1; $i <= count($_SESSION['carrinho']); $i++){
          foreach($_SESSION['carrinho'] as $id_produto_carrinho => $quantidade_produto_carrinho) {
              $read_produto_carrinho = $this->db->query("SELECT * FROM shopping WHERE shop_id = '".$id_produto_carrinho."'");
              if($read_produto_carrinho->rowCount() > 0) {
                  foreach($read_produto_carrinho as $view){
                      if($i == count($_SESSION['carrinho'])){
                          $items .= $view['shop_id'];
                      }else{
                          $items .= $view['shop_id'].', ';
                      }
                  }
              }
          }
      }

      $items = explode(', ', $items);
      for($i = 0; $i < count($_SESSION['carrinho']); $i++){
          if($i+1 == count($_SESSION['carrinho'])){
              $itemsFinal .= $items[$i];
          }else{
              $itemsFinal .= $items[$i].', ';
          }
      }

      $insere = $this->db->prepare("INSERT INTO comprasAguardando(buy_user, buy_items, buy_preco, buy_data, buy_hora, buy_gateway) VALUES(:user, :items, :preco, :data, :hora, :gateway)");
      $insere->bindValue(":user", $_SESSION['usuario']);
      $insere->bindValue(":items", $itemsFinal);
      $insere->bindValue(":preco", $_SESSION['precoFixo']);
      $insere->bindValue(":data", date('Y-m-d'));
      $insere->bindValue(":hora", date('H:i:s'));
      $insere->bindValue(":gateway", 'mercadopago');
      $insere->execute();

      if($insere){
        $user = $_SESSION['usuario'];
        $id = $this->db->query("SELECT buy_id FROM comprasAguardando WHERE buy_user = '$user' ORDER BY buy_data DESC, buy_hora DESC LIMIT 1")->fetchColumn();
        unset($_SESSION['carrinho']);
        unset($_SESSION['precoFixo']);
        return $id;
      }
    }

  }

  public function getPagamento($id){

      global $config;

      if(isset($id) && is_numeric($id)){
          $sql = "SELECT * FROM comprasAguardando WHERE buy_id = '".$id."' AND buy_user = '".$_SESSION['usuario']."'";
          $sql = $this->db->query($sql);
          if($sql->rowCount() > 0){
              foreach($sql as $v){
                if(empty($v['buy_cod'])){
                    do{
                        $cod = rand(9999, 100000);
                        $verifica = "SELECT * FROM comprasAguardando WHERE buy_cod = '".$cod."'";
                        $verifica = $this->db->query($verifica);
                        $verifica2 = "SELECT * FROM comprasAprovadas WHERE buy_cod = '".$cod."'";
                        $verifica2 = $this->db->query($verifica2);
                        $verifica3 = "SELECT * FROM comprasCanceladas WHERE buy_cod = '".$cod."'";
                        $verifica3 = $this->db->query($verifica3);
                        if($verifica->rowCount() == 0 && $verifica2->rowCount() == 0 && $verifica3->rowCount() == 0){
                            $cdg = "UPDATE comprasAguardando SET buy_cod = '".$cod."' WHERE buy_id = '".$id."' AND buy_user = '".$_SESSION['usuario']."'";
                            $cdg = $this->db->query($cdg);
                            $n = 1;
                        }else{
                          $n = 0;
                        }
                    }while($n != 1);
                }else{
                    $cod = $v['buy_cod'];
                }
                if($v['buy_gateway'] == 'mercadopago'){
                  $link = null;
                  $mp = new MP($config['client_id'], $config['client_secret']);
                  $preference_data = array(
                    "items" => array(
                      array(
                        "id" => 0001,
                        "title" => "Pedido #$cod",
                        "description" => "Pedido #$cod",
                        "picture_url" => "http://projeto.danaymo.tk/assets/img/logo.png",
                        "quantity" => 1,
                        "currency_id" => "BRL",
                        "unit_price" => floatval(number_format((float)str_replace(",",".",$v['buy_preco']), 2, '.', ''))
                      )
                    ),
                    "back_urls" => array(
                      "success" => $config['retorno'],
                      "failure" => $config['retorno'],
                      "pending" => $config['retorno']
                    ),
                    "notification_url" => $config['notificacao'],
                    "external_reference" => $cod
                  );
                  $preference = $mp->create_preference($preference_data);
                  $mp->sandbox_mode(FALSE);
                  $link = $preference["response"]["init_point"];
                  echo '<script>window.open("'.$link.'", "_blank")</script>';
                  return "Pagamento gerado com sucesso! Caso o link não tenha sido aberto automaticamente, verifique se seu navegador está permitindo a abertura de janelas pop-ups e tente novamente!";
                }else if($v['buy_gateway'] == 'paypal'){
                  $query = "USER=".$config['paypalUser']."&PWD=".$config['paypalPass']."&SIGNATURE=".$config['paypalSig']."&VERSION=108.0&METHOD=SetExpressCheckout&PAYMENTREQUEST_0_PAYMENTACTION=SALE&PAYMENTREQUEST_0_AMT=".floatval($v['buy_preco'])."&PAYMENTREQUEST_0_CURRENCYCODE=BRL&PAYMENTREQUEST_0_ITEMAMT=".floatval($v['buy_preco'])."&L_PAYMENTREQUEST_0_NAME0=".$cod."&L_PAYMENTREQUEST_0_AMT0=".floatval($v['buy_preco'])."&L_PAYMENTREQUEST_0_QTY0=1&L_PAYMENTREQUEST_0_ITEMAMT=".floatval($v['buy_preco'])."&RETURNURL=".$config['paypalReturn']."&CANCELURL=".$config['paypalCancel']."";
                  $exec = $this->curl($config['paypalLink'], $query);
                  parse_str($exec, $str);
                  if(isset($str['TOKEN'])){
                    $sql = "UPDATE comprasAguardando SET buy_cod = '".$str['TOKEN']."' WHERE buy_id = '".$id."'";
                    $sql = $this->db->query($sql);
                    echo '<script>window.open("https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token='.$str['TOKEN'].'", "_blank")</script>';
                    return 'Pagamento gerado com sucesso!';
                  }else{
                    return 'Erro ao gerar pagamento, favor fale com um administrador!';
                  }
                }else{
                  return 'Gateway de pagamento nao foi encontrada!';
                }
              }
          }else{
              return 'Pedido nao foi encontrado!';
          }
      }else{
          return 'Pedido nao foi setado ou nao é valido!';
      }

  }

}
