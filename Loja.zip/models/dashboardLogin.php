<?php

class dashboardLogin extends model {

  public function logar($user, $pass){

    $sql = "SELECT * FROM dashboard WHERE dash_user = :campo";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":campo", $user);
    $sql->execute();

    if($sql->rowCount() > 0){
      foreach($sql as $view){
        $hash = $view['dash_pass'];
        if(Bcrypt::check($pass, $hash)){
          $_SESSION['logDash'] = 1;
          return "Logado com sucesso!";
        }else{
          return "Erro ao fazer login!";
        }
      }
    }else{
      return "Erro ao fazer login!";
    }

  }

}
