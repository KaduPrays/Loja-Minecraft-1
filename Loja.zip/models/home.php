<?php

class home extends model {

  public function getNoticias(){

    $sql = "SELECT * FROM noticias ORDER BY noticia_data DESC, noticia_hora DESC LIMIT 7";
    $sql = $this->db->query($sql);

    if($sql->rowCount() > 0){
      return $sql->fetchAll();
    }else{
      return false;
    }

  }

  public function getNoticiaFull($id){

    $sql = "SELECT * FROM noticias WHERE noticia_id = :id";
    $sql = $this->db->prepare($sql);
    $sql->bindValue(":id", $id);
    $sql->execute();

    if($sql->rowCount() > 0){
      return $sql->fetchAll();
    }else{
      return false;
    }

  }

}
