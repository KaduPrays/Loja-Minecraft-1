<?php

class pagination extends model {

    public $paginaNumber;

    public function getPagina($item = 1, $table, $prop, $qtd = 1, $w = array(), $wyn = null){

        $array = null;

        $this->paginaNumber = $item;

        $quantidade = $qtd;
        $inicio = abs(($quantidade * $item) - $quantidade);

        $sql = "SELECT * FROM $table";
        $dados = array();
        if(!empty($wyn) && !empty($w) && (is_array($w) && count($w) >= 1)){
            foreach($w as $chave => $valor){
                $dados[] = $chave. " = '". addslashes($valor). "'";
            }
            $sql = $sql." WHERE ".implode(" AND ", $dados)." ORDER BY $prop ASC LIMIT $inicio,$quantidade";
        }else{
            $sql = $sql." ORDER BY $prop ASC LIMIT $inicio,$quantidade";
        }
        $sql = $this->db->query($sql);

        if($sql->rowCount() > 0){

            $array = $sql->fetchAll();

        }

        return $array;

    }

    public function totalPagina($table, $q, $array = array()){

        $sql = "SELECT * FROM $table";
        $dados = array();

        if(!empty($array) && (is_array($array) && count($array) >= 1)){

            foreach($array as $chave => $valor){
                $dados[] = $chave. " = '". addslashes($valor). "'";
            }
            $sql = $sql." WHERE ".implode(" AND ", $dados);

        }

        $sql = $this->db->query($sql);
        $quantia = $sql->rowCount();
        $total = ceil($quantia/$q);

        return $total;

    }

}

?>
