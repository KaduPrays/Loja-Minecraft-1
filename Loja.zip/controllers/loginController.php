<?php

class loginController extends controller {

  public function index(){

    $dados = array();

    $this->loadTemplate("login", $dados);

  }

  public function checkout(){

    if(!empty($_POST['user'])){
      $_SESSION['usuario'] = $_POST['user'];
      $_SESSION['log'] = 1;
      echo "Logado com sucesso!";
    }else{
      echo 'Campos nao foram preenchidos! Favor verifique...';
    }

  }

}
