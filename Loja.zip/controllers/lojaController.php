<?php

class lojaController extends controller {

  public function __construct(){
    $_SESSION['total'] = 0;

    if(!isset($_SESSION['carrinho'])) {
      $_SESSION['carrinho'] = array();
    }
  }

  public function index($cat = null, $option = null, $sec = 1){

    $dados = array();
    $p = new pagination();
    $l = new loja();

    if(isset($cat) && (is_string($cat) && $cat != 'todos') && (is_string($option) && $option == 'pagina') && (isset($sec) && is_numeric($sec))){
      $dados['produtos'] = $p->getPagina($sec, 'shopping', 'shop_id', 9, array("shop_cat" => rawurldecode($cat)), 1);
      $dados['totalPagina'] = $p->totalPagina('shopping', 9, array("shop_cat" => rawurldecode($cat)));
      $dados['paginaAtual'] = $p->paginaNumber;
      $dados['categoriaAtual'] = rawurldecode($cat);
    }else{
      $dados['produtos'] = $p->getPagina($sec, 'shopping', 'shop_id', 9, null, 0);
      $dados['totalPagina'] = $p->totalPagina('shopping', 9, null);
      $dados['categoriaAtual'] = rawurldecode($cat);
    }

    $dados['cat'] = $l->getCat();

    $this->loadTemplate('loja', $dados);

  }

  public function carrinho($arg = null, $id = null){

    $dados = array();
    $p = new loja();

    if(isset($arg) && (is_string($arg) && $arg == 'finalizar')){
      $verifica = $p->getCarrinho();
      if(!empty($verifica)){
        $id = $p->createPedido();
        echo '<script>alert("'.$p->getPagamento($id).'"); window.location = "/loja"</script>';
      }else{
        echo '<script>alert("Você não possui produtos em seu carrinho!"); window.location = "/loja"</script>';
      }
    }else if(isset($arg) && (is_string($arg) && $arg == 'remover') && (isset($id) && is_string($id))){
      $id = str_replace('%20', ' ', $id);
      if($_SESSION['carrinho'][$id] > 1){
        $_SESSION['carrinho'][$id] -= 1;
        echo '<script>alert("Quantidade do produto foi diminuida com sucesso!"); window.location = "/loja/carrinho"</script>';
      }else{
        unset($_SESSION['carrinho'][$id]);
        echo '<script>alert("Produto removido com sucesso!"); window.location = "/loja/carrinho"</script>';
      }
    }else if($arg == 'add' && is_numeric($id)){
      $p->addCarrinho($id);
    }

    $dados['items'] = $p->getCarrinho();

    $this->loadTemplate('carrinho', $dados);

  }

  public function error404(){

    $dados = array();

    $this->loadTemplate('error/404', $dados);

  }

}

?>
