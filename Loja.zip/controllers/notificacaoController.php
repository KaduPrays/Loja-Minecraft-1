<?php

class notificacaoController extends controller {

  public function index() {

    echo '<script>alert("Voce nao pode acessar essa pagina!"); window.location = "/home"</script>';

  }

  public function retorno($s = null){

    $dados = array();
    $p = new plugins();

    $dados['items'] = explode('&', $s);
    $dados['topUser'] = $p->getTOP3();

    $id = explode('&', $s);
    $id = explode('=', $id[0]);
    $idN = $id[1];

    $n = new notificacao();
    $n->get($idN);
    $this->loadTemplate('notificacao', $dados);

  }

  public function error404(){

        $dados = array();

        $this->loadTemplate('404', $dados);

    }


}

?>
