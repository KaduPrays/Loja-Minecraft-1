<?php

class manutencaoController extends controller {

  public function index($arg = null){

    $dados = array();

    $this->loadTemplate('error/manutencao', $dados);

  }

}
