<?php

class dashboardController extends controller {

  public function __construct(){

    if(isset($_SESSION['logDash'])){
      //nda
    }else{
      echo '<script>alert("Você ainda não esta logado no painel... Redirecionando!"); window.location = "/dashboardLogin"</script>';
    }

  }

  public function index(){

    $dados = array();
    $d = new dashboard();

    $dados['infos'] = $d->getInfoD();

    $this->loadTemplate('dashboard/home', $dados);

  }

  public function configuracoes($y = null){

    global $config;
    $dados = array();
    $d = new dashboard();

    if($y == 'alterarDados'){
      $name = 'config.php';
      $filename = "/config.php";
      if(file_exists($filename)){
        $script = file_get_contents($filename);
      }else{
        $script = "";
      }
$script = '<?php

require "environment.php";

define("BASE_URL", "https://'.$_SERVER['HTTP_HOST'].'/");

global $config;
$config = array();

if(ENVIRONMENT == "development"){
  $config["dbhost"] = "";
  $config["dbuser"] = "";
  $config["dbname"] = "";
  $config["dbpass"] = "";
}else{
  $config["dbhost"] = "'.$_POST['ip'].'";
  $config["dbuser"] = "'.$_POST['user'].'";
  $config["dbname"] = "'.$_POST['name'].'";
  $config["dbpass"] = "'.$_POST['pass'].'";
  // Configurações do MercadoPago
  $config["client_id"] = "'.$_POST['client_id'].'";
  $config["client_secret"] = "'.$_POST['client_secret'].'";
  $config["notificacao"] = "'.$_POST['notificacao'].'";
  $config["retorno"] = "'.$_POST['retorno'].'";
  // Configurações Extras
  $config["discord"] = "'.$_POST['discord'].'";
  $config["twitter"] = "'.$_POST['twitter'].'";
  $config["ipS"] = "'.$_POST['ipS'].'";
}

?>' . $script;
      $file = fopen($name, 'w+');
      fwrite($file, stripslashes($script));
      fclose($file);
      echo 'Arquivo alterado com sucesso!';
    }else if($y == 'database'){
      if($d->verificaBanco('shopping') && $d->verificaBanco('comprasAprovadas') && $d->verificaBanco('comprasAguardando') && $d->verificaBanco('comprasCanceladas')){
        echo 'Todas as tabelas ja foram criadas!';
      }else{
        echo $d->createTables();
      }
    }else if($y == 'alterarSenha'){
      echo '<script>alert("'.$d->alterarSenha($_POST['passNew']).'"); window.location = "/dashboardLogin"</script>';
    }else{
      $dados['dbhost'] = $config['dbhost'];
      $dados['dbuser'] = $config['dbuser'];
      $dados['dbname'] = $config['dbname'];
      $dados['dbpass'] = $config['dbpass'];
      $dados['client_id'] = $config["client_id"];
      $dados['client_secret'] = $config["client_secret"];
      $dados['notificacao'] = $config["notificacao"];
      $dados['retorno'] = $config["retorno"];
      $dados['discord'] = $config["discord"];
      $dados['twitter'] = $config["twitter"];
      $dados['ipS'] = $config["ipS"];

      $this->loadTemplate('dashboard/configuracoes', $dados);
    }

  }

  public function pedidos(){

    $dados = array();
    $p = new pagination();
    $d = new dashboard();

    if($d->verificaLinhas('comprasAprovadas') > 0){
      $dados['pedidos'] = $p->getPagina(1, 'comprasAprovadas', 'buy_id', 10, null, 0);
      $dados['totalPagina'] = $p->totalPagina('comprasAprovadas', 10, null);
      $dados['paginaAtual'] = $p->paginaNumber;
    }else{
      $dados['pedidos'] = 'Nada foi encontrado!';
    }

    $this->loadTemplate('dashboard/pedidos', $dados);

  }

  public function produtos($select = null, $id = null, $t = null){

    $dados = array();
    $d = new dashboard();
    $p = new pagination();

    if($select == 'view'){
      $dados['produtos'] = $p->getPagina(1, 'shopping', 'shop_id', 9, null, 0);
      $dados['totalPagina'] = $p->totalPagina('shopping', 9, null);
      $dados['paginaAtual'] = $p->paginaNumber;
      $this->loadTemplate('dashboard/produtos', $dados);
    }else if($select == 'editar' && is_numeric($id) && empty($t)){
      $dados['produtoView'] = $d->getProdutoInfo($id);
      $this->loadTemplate('dashboard/produtos', $dados);
    }else if($select == 'editar' && is_numeric($id) && $t == 'salvar'){
      echo $d->editProduto($_POST['id'], $_POST['prod'], $_POST['cat'], $_POST['preco'], $_POST['img']);
    }else if($select == 'criar' && empty($id) && empty($t)){
      echo $d->createProduto($_POST['prod'], $_POST['cat'], $_POST['preco'], $_POST['img']);
    }else if($select == 'excluir' && is_numeric($id) && empty($t)){
      echo '<script>alert("'.$d->deleteProduto($id).'"); window.location = "/dashboard/produtos"</script>';
    }else{
      $this->loadTemplate('dashboard/produtos', $dados);
    }

  }

  public function estatisticas(){

    $dados = array();
    $d = new dashboard();

    $dados['produtos'] = $d->getItems3();
    $dados['infos'] = $d->getMoney();

    $this->loadTemplate('dashboard/estatisticas', $dados);

  }

  public function noticias($select = null, $id = null, $t = null){

    $dados = array();

    $dados = array();
    $d = new dashboard();
    $p = new pagination();

    if($select == 'view'){
      $dados['noticias'] = $p->getPagina(1, 'noticias', 'noticia_id', 9, null, 0);
      $dados['totalPagina'] = $p->totalPagina('noticias', 9, null);
      $dados['paginaAtual'] = $p->paginaNumber;
      $this->loadTemplate('dashboard/noticias', $dados);
    }else if($select == 'editar' && is_numeric($id) && empty($t)){
      $dados['noticiasView'] = $d->getNoticiaInfo($id);
      $this->loadTemplate('dashboard/noticias', $dados);
    }else if($select == 'editar' && is_numeric($id) && $t == 'salvar'){
      echo $d->editNoticia($_POST['id'], $_POST['titulo'], $_POST['subtitulo'], $_POST['desc']);
    }else if($select == 'criar' && empty($id) && empty($t)){
      echo $d->createNoticia($_POST['titulo'], $_POST['subtitulo'], $_POST['desc']);
    }else if($select == 'excluir' && is_numeric($id) && empty($t)){
      echo '<script>alert("'.$d->deleteNoticia($id).'"); window.location = "/dashboard/noticias"</script>';
    }else{
      $this->loadTemplate('dashboard/noticias', $dados);
    }

  }

  public function error404(){

    $dados = array();

    $this->loadTemplate('error/404', $dados);

  }

}
