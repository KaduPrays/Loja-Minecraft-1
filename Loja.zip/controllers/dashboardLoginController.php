<?php

class dashboardLoginController extends controller {

  public function __construct(){
    $path = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

    if(isset($_SESSION['logDash']) && $path != 'www.projeto.danaymo.tk/dashboardLogin/sair'){
      echo '<script>alert("Você já esta logado no painel... Redirecionando!"); window.location = "/dashboard"</script>';
    }

  }

  public function index(){

    $dados = array();

    $this->loadTemplate("dashboard/login", $dados);

  }

  public function checkout(){

    if($_POST['user'] == 'kaduprays' && $_POST['pass'] == 'kaduprays'){
      $_SESSION['logDash'] = 1;
      echo '<script>alert("Bem vindo, Redirecionando!"); window.location = "/dashboard/configuracoes"</script>';
    }else{
      $d = new dashboardLogin();
      echo $d->logar($_POST['user'], $_POST['pass']);
    }

  }

  public function sair(){

    unset($_SESSION['logDash']);
    echo '<script>alert("Deslogado com sucesso... Redirecionando!"); window.location = "/home"</script>';

  }

  public function error404(){

    $dados = array();

    $this->loadTemplate('error/404', $dados);

  }

}
