<?php

class homeController extends controller {

    public function index(){

      global $config;

      $dados = array();
      $h = new home();

      $dados['twitter'] = $config['twitter'];
      $dados['discord'] = $config['discord'];
      $dados['noticias'] = $h->getNoticias();

      $this->loadTemplate('home', $dados);

    }

    public function noticia($id = null){

      $dados = array();
      $h = new home();

      if(empty($id) || !is_numeric($id)){
        $dados['twitter'] = $config['twitter'];
        $dados['discord'] = $config['discord'];
        $dados['noticias'] = $h->getNoticias();
        $this->loadTemplate('home', $dados);
      }else{

        $dados['noticiaView'] = $h->getNoticiaFull($id);

        $this->loadTemplate('noticia', $dados);
      }

    }

    public function error404(){

        $dados = array();

        $this->loadTemplate('error/404', $dados);

    }

}

?>
